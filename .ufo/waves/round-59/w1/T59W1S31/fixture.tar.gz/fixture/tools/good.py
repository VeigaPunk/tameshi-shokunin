print("trusted")
